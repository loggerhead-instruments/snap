var searchData=
[
  ['nullptr',['nullptr',['../_sys_call_8h.html#ab979d9d4b4923f7c54d6caa6e1a61936',1,'SysCall.h']]]
];
