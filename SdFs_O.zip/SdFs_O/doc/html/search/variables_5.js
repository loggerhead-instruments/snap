var searchData=
[
  ['eofbit',['eofbit',['../classios__base.html#af75072b7ef2a931c77a2cb8e7ccda460',1,'ios_base']]]
];
