var searchData=
[
  ['unselect',['unselect',['../class_sd_spi_lib_driver.html#a593b443dca85fe4de76ab06547233429',1,'SdSpiLibDriver::unselect()'],['../class_sd_spi_alt_driver.html#a731497cc1efc4bd0875d61b0d84979ff',1,'SdSpiAltDriver::unselect()']]],
  ['unsetf',['unsetf',['../classios__base.html#a3bf7d054a433ed15e8b984e16f630fa4',1,'ios_base']]],
  ['uppercase',['uppercase',['../ios_8h.html#af5d5e1a0effa1b500bb882feed5a2061',1,'ios.h']]],
  ['usedma',['useDma',['../class_sdio_config.html#a07ddb8b18bf24fa61fdd289a112e79a8',1,'SdioConfig']]]
];
