var searchData=
[
  ['uppercase',['uppercase',['../classios__base.html#ade3db1fe3249e87f4c47a9a8916793d9',1,'ios_base']]]
];
