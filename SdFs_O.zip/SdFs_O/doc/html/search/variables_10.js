var searchData=
[
  ['trunc',['trunc',['../classios__base.html#ae62b8972f37509819e1384214071194b',1,'ios_base']]]
];
